export function mult(n1, n2){
let resultado = n1 * n2
console.log(resultado)
return resultado
}